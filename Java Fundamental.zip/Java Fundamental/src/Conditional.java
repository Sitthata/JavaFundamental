public class Conditional {

    public static void main(String[] args) {
        /*
    Syntax
    if (condition | boolean ) {
        // DO or CHECK something if true do this chunk of code
    }

    if (condition | boolean) {
        // the condition (boolean) is true do this chunk of code
    } else if (condition | boolean ) {
        // check the condition true? if true do this chunk of code
    }

     */
    }

    public static String testQuiz1() {
        int number = 0;
        /*
         Check if the number is positive or not

         Test Data
         Input Data : 35
         Expected Output: (NUMBER) is positive
         */
        return "";
    }

    public static String testQuiz2() {
        // Input between 1 - 7 return the name of that week day if non matches return "No day matches"
        int inputDay = 0;
        return "";
    }


}
